import io, os, re
from flask import Flask, request, send_file, render_template_string, abort
from resume import build_resume

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024

PAGE = r"""<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>ResumeSov</title>
<style>:root{color-scheme:light dark}*{box-sizing:border-box}body{font:15px system-ui;max-width:780px;margin:30px auto;padding:0 14px}
fieldset{margin:14px 0;border:1px solid #8884;border-radius:10px;padding:12px}legend{font-weight:700;padding:0 6px}
label{display:block;font-weight:600;font-size:13px;margin:8px 0 3px}input,select,textarea,button{width:100%;padding:8px;font:inherit;margin-bottom:6px}
textarea{min-height:70px}.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.card{border:1px dashed #8886;border-radius:8px;padding:10px;margin:8px 0}button{cursor:pointer;font-weight:700}
.sec{width:auto;padding:6px 12px;font-weight:600;margin-right:6px}small{opacity:.7}</style>
<h1>📄 ResumeSov</h1>
<small>Build an ATS-friendly resume PDF. Runs on your own server: no accounts, nothing stored there. Your data autosaves only in this browser.</small>
<p><button type=button class=sec onclick=exportJ()>Export backup (.json)</button>
<label class=sec style="display:inline-block;cursor:pointer;border:1px solid #8886;border-radius:4px;margin:0">Import backup<input type=file accept=".json" onchange=importJ(this) hidden></label>
<button type=button class=sec onclick=clearAll()>Clear</button></p>
<form id=f method=post action=/generate enctype=multipart/form-data>
<fieldset><legend>Design</legend><div class=g>
<div><label>Template</label><select name=template id=template><option value=modern>Modern (color header)<option value=classic>Classic (serif)<option value=sidebar>Sidebar (two-column)</select></div>
<div><label>Accent color</label><input type=color name=accent id=accent value="#1d4ed8"></div>
<div><label>Photo (optional)</label><input type=file name=photo accept="image/*"></div></div></fieldset>
<fieldset><legend>About you</legend><div class=g>
<div><label>Full name</label><input name=name id=name required></div><div><label>Job title</label><input name=title id=title></div>
<div><label>Email</label><input name=email id=email></div><div><label>Phone</label><input name=phone id=phone></div>
<div><label>Location</label><input name=location id=location></div></div>
<label>Links (LinkedIn, portfolio, GitHub: one per line)</label><textarea name=links id=links></textarea>
<label>Profile summary (2-3 sentences)</label><textarea name=summary id=summary></textarea></fieldset>
<fieldset><legend>Experience</legend><div id=exp></div><button type=button class=sec onclick="addExp();save()">+ Add job</button></fieldset>
<fieldset><legend>Education</legend><div id=edu></div><button type=button class=sec onclick="addEdu();save()">+ Add school</button></fieldset>
<fieldset><legend>Skills &amp; extras</legend><label>Skills (comma or line separated)</label><textarea name=skills id=skills></textarea>
<label>Languages</label><input name=languages id=languages placeholder="English (fluent), Filipino (native)">
<label>Certifications &amp; awards (one per line)</label><textarea name=certs id=certs></textarea></fieldset>
<button>Download PDF resume</button></form>
<script>
const $=i=>document.getElementById(i),S=['template','accent','name','title','email','phone','location','links','summary','skills','languages','certs'];
const EF=['role','company','dates','bullets'],DF=['school','degree','dates','notes'];
function row(box,pre,fields,ph,o={}){const c=document.createElement('div');c.className='card';
c.innerHTML=fields.map((f,i)=>f=='bullets'||f=='notes'?`<textarea name=${pre}_${f} placeholder="${ph[i]}"></textarea>`:`<input name=${pre}_${f} placeholder="${ph[i]}">`).join('')+
'<button type=button class=sec onclick="this.parentNode.remove();save()">Remove</button>';
fields.forEach(f=>c.querySelector(`[name=${pre}_${f}]`).value=o[f]||'');$(box).appendChild(c)}
const addExp=o=>row('exp','exp',EF,['Job title','Company','Jan 2022 - Present','One achievement per line (start with action verbs, add numbers)'],o);
const addEdu=o=>row('edu','edu',DF,['School','Degree / course','2016 - 2020','Honors, GPA, relevant notes (optional)'],o);
const grab=(box,pre,F)=>[...document.querySelectorAll(`#${box} .card`)].map(c=>Object.fromEntries(F.map(f=>[f,c.querySelector(`[name=${pre}_${f}]`).value])));
function state(){const s=Object.fromEntries(S.map(k=>[k,$(k).value]));s.exp=grab('exp','exp',EF);s.edu=grab('edu','edu',DF);return s}
function save(){try{localStorage.setItem('rsov',JSON.stringify(state()))}catch(e){}}
function load(s){S.forEach(k=>{if(s[k]!==undefined)$(k).value=s[k]});$('exp').innerHTML='';$('edu').innerHTML='';
(s.exp&&s.exp.length?s.exp:[{}]).forEach(addExp);(s.edu&&s.edu.length?s.edu:[{}]).forEach(addEdu)}
function exportJ(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state())],{type:'application/json'}));a.download='resume-backup.json';a.click()}
function importJ(i){const r=new FileReader();r.onload=()=>{try{load(JSON.parse(r.result));save()}catch(e){alert('Invalid backup file')}};r.readAsText(i.files[0])}
function clearAll(){if(confirm('Clear everything?')){load({});save()}}
let s={};try{s=JSON.parse(localStorage.getItem('rsov')||'{}')}catch(e){}load(s);
$('f').addEventListener('input',save);
</script>"""

@app.get("/")
def home(): return render_template_string(PAGE)

@app.post("/generate")
def generate():
    f = request.form; g = lambda k, n=200: (f.get(k) or "").strip()[:n]
    zipf = lambda *keys: [dict(zip([k.split("_", 1)[1] for k in keys], v)) for v in zip(*[f.getlist(k) for k in keys])]
    accent = g("accent", 7); accent = accent if re.fullmatch(r"#[0-9a-fA-F]{6}", accent) else "#1d4ed8"
    tpl = g("template", 12); tpl = tpl if tpl in ("modern", "classic", "sidebar") else "modern"
    d = dict(template=tpl, accent=accent, name=g("name", 80), title=g("title", 100), email=g("email", 100), phone=g("phone", 40),
             location=g("location", 100), links=g("links", 400), summary=g("summary", 900), skills=g("skills", 900),
             languages=g("languages", 300), certs=g("certs", 900),
             exp=[{k: v[:1500] for k, v in e.items()} for e in zipf("exp_role", "exp_company", "exp_dates", "exp_bullets")][:12],
             edu=[{k: v[:400] for k, v in e.items()} for e in zipf("edu_school", "edu_degree", "edu_dates", "edu_notes")][:8])
    ph = request.files.get("photo"); photo = ph.read() if ph and ph.filename else None
    try:
        pdf = build_resume(d, photo)
    except Exception as e:
        abort(400, f"Could not build resume: {e}")
    fn = re.sub(r"[^A-Za-z0-9_-]+", "-", d["name"] or "resume").strip("-") or "resume"
    return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True, download_name=f"{fn}-resume.pdf")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
